import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

public class wordleclass {
    public static void main(String[] args) {
        String answer = "brick";
        answer = answer.toUpperCase(Locale.ROOT);
        if (answer.length() != 5) {
            System.out.println("original word isn't 5 letters");
        } else {
            wordlegame(answer);
        }
    }

    public static void wordlegame(String answer) {
        String[][] userguesses = new String[12][5];
        Scanner s = new Scanner(System.in);
        String guess;
        boolean checker = false;
        String[] arrayguess = new String[5];
        int indexint;
        int guessnumber = 1;
        System.out.println("Welcome to Wordle! *'s are correct, @'s are in the wrong spot, x's are incorrect. Please enter a five letter word to start:");
        for (int w = 0; w <= 10; w = w + 2) {
            System.out.println("Guess #" + (guessnumber));
            guessnumber++;
            guess = s.nextLine();
            guess = guess.toUpperCase(Locale.ROOT);
            if (guess.equals(answer)) {
                System.out.println("Congrats you win");
                w += 20;
                checker = true;
            }
            else if (guess.length() != 5) {
                System.out.println("Word isn't 5 letters, try again");
                w -= 2;
                guessnumber--;
            }
            else {
                for (int i = 0; i < 5; i++) {
                    userguesses[w][i] = guess.substring(i, i + 1);
                }
                for (int i = 0; i < 5; i++) {
                    indexint = answer.indexOf(guess.substring(i, i + 1));
                    if (indexint == i) {
                        userguesses[w + 1][i] = "*";
                    } else if (indexint != -1) {
                        userguesses[w + 1][i] = "@";
                    } else {
                        userguesses[w + 1][i] = "x";
                    }
                }
                System.out.println(Arrays.deepToString(userguesses[w]));
                System.out.println(Arrays.deepToString(userguesses[w + 1]));
            }
        }
        if (checker == false){
            System.out.println("Sorry you lost :(");
        }
    }
}

