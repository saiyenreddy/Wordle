import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

public class wordle {
    public static void main(String[] args) {
        String theword = "Brick";
        theword=theword.toUpperCase(Locale.ROOT);
        char[] arrayguess = new char[5];
        if(theword.length()!=5){
            System.out.println("original word isn't 5 letters");
        }else{
           arrayguess=(chararraycreator(theword));
        }
wordlegame(arrayguess);

    }
    public static void wordlegame(char[] answer){
        boolean reset = false;
        char[][] userguesses = new char[5][12];
        Scanner s = new Scanner(System.in);
        System.out.println("First Guess");
        String guess = s.nextLine();
        char guessarray[] = new char[5];
        char checkarray[] = new char[5];
        guessarray=chararraycreator(guess);
        for(int i = 0; i < 5 ; i ++){
            userguesses[i][0]=guessarray[i];
        }
        for(int z = 0 ; z <5 ; z++){
        for(int i = 0 ; i<5;i++) {
            if (guessarray[i]==answer[i]){
                checkarray[z]='*';
                reset=true;
            }
            for (int w = 1; w < 5; w++) {
                if (guessarray[w]==answer[i]){
                    checkarray[z]='@';
                    reset=true;
                }
            }
        }
        if(reset=false){
            checkarray[z]='x';
            reset=true;
        }
        }
        String kaizhou = Arrays.toString(userguesses);
    
        // end of guess one


    }
    public static char[] chararraycreator(String word){
        char[] arrayguess = new char[5];
        for (int i = 0;i<5;i++){
            arrayguess[i]=word.charAt(i);
        }
        return arrayguess;
    }


}
